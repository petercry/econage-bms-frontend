export const SET_SYS_WIDTH = 'SET_SYS_WIDTH'

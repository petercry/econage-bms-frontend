import {EcoUtil} from '@/components/util/main.js'
let baseUrl = EcoUtil.getBaseUrl();

let sysEnv = 1; //0 测试 1 正式  很重要

export{
  baseUrl,sysEnv
}

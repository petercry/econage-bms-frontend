
export default {
  common: {
      loading:'ロード中...',
      second:'秒',
      username:'ユーザ名',
      password:'パスワード',
      login:'陸に上がる',
      tip:'ヒント'
  },
  table:{
    
  },
  tool:{
      
  },
  form:{
  },
  message:{
      msg1:'すみません、システムはユーザー名とパスワードを入力して再登録する必要があります。これは長い間サーバーとの相互作用がないからかもしれません。さもないとシステムは',
      msg2:'後自動終了',
      msg3:'すみません、検証に失敗しました。もう一度試してみてください'
  },
  button:{
  }

}
export default {
  common: {
      loading:'加载中...',
      second:'秒',
      username:'用户名',
      password:'密码',
      login:'登陆',
      tip:'提示'
  },
  table:{
    
  },
  tool:{
     
  },
  form:{
  },
  message:{
    msg1:'对不起，系统需要您输入用户名和密码以重新登录。这可能是由于您长时间没有与服务器进行交互。否则系统将在',
    msg2:'后自动退出',
    msg3:'对不起，未通过验证，请再次尝试'
  },
  button:{
  }

}

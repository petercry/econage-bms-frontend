<template>
    <div class="designGridInputGrid designItem designGridItem" >
        <div style="line-height:31px"><span class="attachment"><i class="icon iconfont iconfujian"></i>上传附件</span></div>
    </div>
</template>
<script>

export default{
  name:'designGridInputGrid',
  components:{
     
  },
  props:{
        itemObj:{
            type:Object
        }
  },
  data(){
        return {
            value:'',
           
        }
  },
  computed:{
        
      
  },
  created(){
     
  },
  mounted(){
      
   
  },
  methods: {
     
  },
  watch: {
 
  }
}
</script>
<style scoped>

</style>

<template>
  <div class="handleApiVue designItem" v-show="isVisible">

      <ecoField :titleWidth="mItem.titleWidth?mItem.titleWidth:defaultTitleWidth" :bgColor="mItem.bgColor?mItem.bgColor:mForm?mForm.titleBgColor:null" 
            :titlePos="mItem.titlePos" :required="isRequired" v-bind:class="{'iptReadonly':!isEditable}" class="handleField"
            :textAlign="mItem.titleAlign"
            :verticalAlign="mItem.verticalAlign?mItem.verticalAlign:'top'"
        >
            
            <div slot="label"  v-bind:style="{textAlign:mItem.titleAlign}">
                    <div class="labelTitle" >
                        <i v-if="isRequired && mItem.titleAlign != 'left'" class="el-form-required-i labelTitleRequestI">*</i>
                        <span v-bind:style="{color:mItem.ftColor?mItem.ftColor:mForm?mForm.titleTextColor:null}">{{mItem.itemName}}</span>
                        <el-tooltip class="item" effect="dark" :content="errMsg" placement="left" :value='errTip' >
                                <span></span>
                        </el-tooltip>

                    </div>
            </div>

            <div slot="content" style="position:relative;text-align:center"> 
                    <el-button type="primary" size="mini" @click="onClickEvent" :disabled="!isEditable">{{mItem.fileUploadbutton}}</el-button>
                    <!-- <el-input 
                        :value="value"  
                        readonly
                        v-bind:class="{'iptReadonly':!isEditable,'iptPage':hasClick,'pointerCalss':hasClick}"
                        :placeholder="(mItem.inst && mItem.inst !='')?mItem.inst:''"
                        ref="iptRef"
                        @change="onChangeEvent"
                        @blur="onblurEvent"
                        @click.native="onClickEvent"
                        :id="'handleItem'+mItem.itemId"
                        type="textarea" 
                        :autosize="{minRows:1,maxRows:5}"  
                    >
                    </el-input> -->
                    <!-- <i class="icon iconfont iconclose pointerClass deleteIcon" v-if="isEditable" @click="clearApi"></i> -->
            </div> 
     </ecoField>
      
  </div>
</template>
<script>

import ecoField from '../../components/ecoField'
import {EcoUtil} from '@/components/util/main.js'
import {EcoMessageBox} from '@/components/messageBox/main.js'
import {defaultTitleWidth,defaultFTColor}  from'../../../config/setting.js'

export default{
  name:'handleApi',
  components:{
      ecoField
  },
  props:{
        mItem:{
            type:Object
        },
        mValue:{
            type:Object
        },

        mForm:{
            type:Object
        }
  },
  data(){
        return {
            value:'',
            hiddenValue:'',

            isRequired:false,
            isVisible:true, //是否可见
            isReadonly:false, //是否只读
            isEditable:true, //是否需要上传后台
            hasClick:false,
            iptType:'',
            errTip:false,
            errMsg:'',
        }
  },
  created(){
       
  },
  mounted(){
       if(this.mItem && this.mItem.nullable == 0){
           this.isRequired = true;
       }
       if(this.mItem && this.mItem.visiable == 0){
           this.isVisible = false;
       }

       if(this.mItem && this.mItem.isReadonly == 1 ){
           this.isReadonly = true;
       }

       if(this.mItem && this.mItem.editable == 0){
           this.isEditable = false;
       }

       if((this.mValue.onclickEvents && this.mValue.onclickEvents.length > 0)){
            this.hasClick = true;
       }

       /*类型*/
       if(this.mValue && this.mValue.valType == 'NUMBER'){
           this.iptType = 'number';
       }
       this.value = this.mValue.value ;
       this.hiddenValue = this.mValue.hiddenValue;

            
  },
  computed:{
    
  },
  methods: {

       /*触发点击焦点事件*/
       onClickEvent(){     
                (this.mValue.onclickEvents).forEach((eventKey)=>{
                        let _emit = {};
                        _emit.action = 'onEventKeyAction'
                        _emit.data = {};
                        _emit.data.itemId = this.mItem.itemId;
                        _emit.data.eventKey = eventKey;
                        _emit.data.eventModuleReadOnly = this.isReadonly; 
                        _emit.data.eventValue = this.value;
                        this.$emit('emitEvent',_emit); 
                });
           

                this.onInteraction();
       },

       /*失去焦点事件*/ 
       onblurEvent(){
            (this.mValue.onblurEvents).forEach((eventKey)=>{
                        let _emit = {};
                        _emit.action = 'onEventKeyAction'
                        _emit.data = {};
                        _emit.data.itemId = this.mItem.itemId;
                        _emit.data.eventKey = eventKey;
                        this.$emit('emitEvent',_emit); 
             })
            
        },

        /*chang事件*/
        onChangeEvent(){ 
            (this.mValue.onchangeEvents).forEach((eventKey)=>{
                    let _emit = {};
                    _emit.action = 'onEventKeyAction'
                    _emit.data = {};
                    _emit.data.itemId = this.mItem.itemId;
                    _emit.data.eventKey = eventKey;
                    this.$emit('emitEvent',_emit); 
            });

            this.emitMirrorEvent();
        },

        /*相关性*/
        onInteraction(){
          
            if(this.mValue.hasInteraction){
                    let _emit = {};
                    _emit.action = 'onInteractionAction'
                    _emit.data = {};
                    _emit.data.itemId = this.mItem.itemId;
                    this.$emit('emitEvent',_emit);
            }
        },

       

        /*Override 获取某个item的值*/
        getItemInputParamsValue(){  
             let _obj = {};
             _obj.value = this.value
             _obj.hiddenValue = this.hiddenValue;
             return _obj;
        },

        /*Override 设置item的值*/
        setItemOutputParamsValue(value,hiddenValue,fromItemId){ 
            this.value = value;
            this.hiddenValue = hiddenValue;
            if(this.mItem.itemId != fromItemId){ //如果触发元不是本组件，接着触发本组件的chang事件
                    this.onChangeEvent();
                    this.onblurEvent();
               
            }
        },

        /*设置相关性*/
        setItemInteraction(event){
            if(event.eventType == 'SET_VISIBALE'){
                 if(event.eventSource.val == 0){
                     this.isVisible = false;
                 }else{
                     this.isVisible = true;
                 }

                  this.emitItemVisibleAction(event.eventSource.val);
            }else if(event.eventType == 'SET_NULLABLE'){
                if(event.eventSource.val == 0){
                    this.isRequired = true;
                }else{
                    this.isRequired = false;
                }
            } else if(event.eventType == 'SET_READONLY'){
                if(event.eventSource.val == 1){
                    this.isReadonly = true;
                }else{
                    this.isReadonly = false;
                }
           }else if(event.eventType == 'SET_VAL'){
                 this.value = event.eventSource.val.value;
                 this.hiddenValue = event.eventSource.val.hiddenValue;
                 
                this.onChangeEvent(); //触发改变事件
                this.onblurEvent(); //触发失去焦点事件
               
                 
            }
        },

         emitItemVisibleAction(visiable){
             let _emit = {};
             _emit.action = 'onItemVisibleAction'
             _emit.data = {};
             _emit.data.itemId = this.mItem.itemId;
             _emit.data.visiable = visiable;
             this.$emit('emitEvent',_emit); 
        },

        /*接受事件的回写*/
       callEvent(obj,outputParams){ 
      
          if(obj.action == 'PAGE' || obj.action == 'APIPAGE'){ 
                if(outputParams.name !='out0'){
                        // (obj.selItems).forEach((element,idx)=>{
                        //     this.value = element[outputParams.name];
                        // })

                        let _valueArr = [];
                        (obj.selItems).forEach((element,idx)=>{
                            _valueArr.push(element[outputParams.name]);
                        })
                        this.value = _valueArr.join(';'); 

                }else{
                      /*全部赋值*/
                      if(obj.selItems){
                            let _value = '';
                            let _hiddenValue = '';
                            (obj.selItems).forEach((element,idx)=>{
                                    if(_hiddenValue !=''){
                                        _hiddenValue +='|';
                                    }
                                    if(_value!=''){
                                        _value+=';';
                                    }
                                    _hiddenValue += element.hiddenValue;
                                    _value += element.value;
                            })
                            this.value = _value;
                            this.hiddenValue = _hiddenValue;
                    }
                }
            }

            this.onChangeEvent();
            this.onblurEvent();
         
       },


       callRelWFEvent(selItems){
             (selItems).forEach((element,idx)=>{
                    this.value = element.value;
                    this.hiddenValue = element.hiddenValue;
              })
             
             this.onblurEvent();
             this.onChangeEvent();
        },

        /*提交的时候，获取*/
        getRefValue(){ 
             let _obj = null;
             if(this.isEditable){ //isEditable 提交
                 _obj  = {};
                 _obj.value = this.value;
                 _obj.hiddenValue = this.hiddenValue;
             }
             return _obj;
       },

       /*检查 是否可以提交*/
       getRefCheck(){ 
            if(this.isEditable ){
                if(this.isRequired ){
                    if(!this.value || this.value == ''){
                        return { status:1,msg:this.mItem.itemName+' 必须填写',checkType:'TEXTFIELD',checkId:'handleItem'+this.mItem.itemId,itemId:this.mItem.itemId} ;
                    }
                }
            }
            return {status:0}
        },

      doRefCheck(obj){
            try{
                   this.errTip = true;
                   this.errMsg = obj.msg;
                   let that = this;
                   setTimeout(function(){
                        that.errTip = false;
                   },2000);
                //    document.getElementById('handleItem'+this.mItem.itemId).scrollIntoView(true);
                   document.getElementById('handleItem'+this.mItem.itemId).focus();
            }catch(e){
                console.log(e);
            }
        },

        clearApi(){
            (this.mValue.onclickEvents).forEach((eventKey)=>{
                    let _emit = {};
                    _emit.action = 'onEventKeyAction'
                    _emit.data = {};
                    _emit.data.clearBtn = true;
                    _emit.data.itemId = this.mItem.itemId;
                    _emit.data.eventKey = eventKey;
                    _emit.data.eventModuleReadOnly = this.isReadonly; 
                    _emit.data.eventValue = this.value;
                    this.$emit('emitEvent',_emit); 
            })
        },

         /*镜像映射*/
        emitMirrorEvent(){ 
            if(this.mValue.itemIdToViewList && this.mValue.itemIdToViewList.length > 0){
                let _emitViewItemMap = [];
                for(let i = 0;i<this.mValue.itemIdToViewList.length;i++){
                    if(this.mItem.viewId != this.mValue.itemIdToViewList[i]){
                        _emitViewItemMap[String(this.mValue.itemIdToViewList[i])] = 1;
                    }
                }
                let _emit = {};
                _emit.action = 'onMirrorEmitAction'
                _emit.data = {};
                _emit.data.itemId = this.mItem.itemId;
                _emit.data.mirrorViewItem = _emitViewItemMap;
                
                _emit.data.mirrorData = {};
                _emit.data.mirrorData.value = this.value;
                _emit.data.mirrorData.hiddenValue = this.hiddenValue;
                _emit.data.mirrorData.isRequired = this.isRequired;
                _emit.data.mirrorData.isVisible = this.isVisible;
                _emit.data.mirrorData.isReadonly = this.isReadonly;
                _emit.data.mirrorData.isEditable = this.isEditable;

                this.$emit('emitEvent',_emit); 
            }
        },

        callMirror(data){
            if(data.mirrorData){
                this.value = data.mirrorData.value;
                this.hiddenValue = data.mirrorData.hiddenValue;
                this.isRequired = data.mirrorData.isRequired;
                this.isVisible = data.mirrorData.isVisible;
                this.isReadonly = data.mirrorData.isReadonly;
                this.isEditable = data.mirrorData.isEditable;
            }
        }
        /*镜像映射 结束*/
  },
  watch: {

  }
}
</script>
<style scoped>

.handleApiVue .deleteIcon{
    position: absolute;
    right:3px;
    color:rgb(192, 196, 204);
    font-size: 12px;
}

</style>

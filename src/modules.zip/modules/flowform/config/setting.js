let defaultFormWidth = 750; //默认表单宽度
let defaultTitleWidth = 100; //默认标题宽度
let deafultSelectItemWidth = 0;

let defaultColDateTitleWidth = 145; //默认标题宽度

let defaultFTColor = '#606266'; //默认标题文字颜色

let defaultFormTitleTextColor = '#262626';// 默认标题颜色
let defaultFormTitleBgColor="#fafafa"; //默认标题背景颜色

export{
    defaultFormWidth,defaultTitleWidth,defaultColDateTitleWidth,defaultFTColor,defaultFormTitleTextColor,defaultFormTitleBgColor,deafultSelectItemWidth
}

export const SET_DEMO = 'SET_DEMO'
export const SET_TEMP_OBJ = 'SET_TEMP_OBJ'
export const DELETE_TEMP_OBJ = 'DELETE_TEMP_OBJ'
let newsType =4;
export{
  newsType
}

<template>
    <webMain></webMain>
</template>

<script>
import webMain from './webMain.vue'
import {EcoUtil} from '@/components/util/main.js'

export default {
  components: {
      webMain
  },
  data() {
    return {
    };
  },
  created() {

     
  },
  mounted() {
      
  },
  methods: {
       
  },

  destroyed() {}
};
</script>



<style scoped>
.webPlatform {

}

</style>

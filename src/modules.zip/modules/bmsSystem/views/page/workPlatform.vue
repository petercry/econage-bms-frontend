<template>
    <div class="workPlatform">
        <eAside></eAside>
        <eMain></eMain>
    </div>
</template>

<script>

import eAside from '../../views/layout/eAside.vue'
import eMain from '../../views/layout/eMain.vue'

import {EcoUtil} from '@/components/util/main.js'


export default {
  components: {
      eAside,
      eMain
  },
  data() {
    return {
       
    };
  },
  created() {

     
  },
  mounted() {
      
  },
  methods: {
       
  },

  destroyed() {}
};
</script>



<style scoped>
.workPlatform {

 
}

</style>

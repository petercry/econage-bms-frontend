export default {
  common: {
      loading:'加载中...',
  },
  table:{
    
  },
  tool:{
     
  },
  form:{
  },
  message:{

  },
  button:{
  }

}

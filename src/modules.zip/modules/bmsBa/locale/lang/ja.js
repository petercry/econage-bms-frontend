
export default {
  common: {
      loading:'ロード中...',
  },
  table:{
    
  },
  tool:{
      
  },
  form:{
  },
  message:{

  },
  button:{
  }

}
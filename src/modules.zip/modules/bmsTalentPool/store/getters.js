const getters = {
  baseData:state => {
      return state.baseData;
  },
  getBaseDataTextByKey:state => (id,key) => {
      if(!id || !key) return '';
      let _find = state.baseData[key].data.find(single => single.id == id);
      return _find?_find.text:'';
  }
}
export default getters

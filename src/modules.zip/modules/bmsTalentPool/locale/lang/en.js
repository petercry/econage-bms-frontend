export default {
  common: {
      loading:'Loading...',
  },
  table:{
    
  },
  tool:{
      
  },
  form:{
  },
  message:{

  },
  button:{
  }
}
